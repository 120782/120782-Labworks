#include <iostream>

// Function to calculate the average of student marks
float markAverage(float marks[], int size) {
    float sum = 0.0;

    // Calculate the sum of marks
    for (int i = 0; i < size; ++i) {
        sum += marks[i];
    }

    // Calculate and return the average
    return sum / size;
}

int main() {
    const int numStudents = 7;
    float studentMarks[numStudents];

    // Input student marks
    std::cout << "Enter the marks for 7 students:\n";
    for (int i = 0; i < numStudents; ++i) {
        std::cout << "Enter mark for student " << i + 1 << ": ";
        std::cin >> studentMarks[i];
    }

    // Calculate average using markAverage() function
    float average = markAverage(studentMarks, numStudents);

    // Display the average to the user
    std::cout << "The average of the marks is: " << average << std::endl;

    return 0;
}
